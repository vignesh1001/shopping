interface IProfileRequest {
  email?: string
  firstName?: string
  lastName?: string
  fullname?: string
  photo?: string
  country?: string
  state?: string
  county?: string
  city?: string
  zipCode?: string
  address?: string
}
