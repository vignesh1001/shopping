# next-redux-saga-typescript example

> This example is based on the [with-redux-saga](https://github.com/zeit/next.js/tree/master/examples/with-redux-saga) example.

## How to use

Install it and run:

```bash
npm install
npm run dev
# or
yarn
yarn dev
```
